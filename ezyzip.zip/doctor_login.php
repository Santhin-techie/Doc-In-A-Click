<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "edoc");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
$message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $Gmail = trim($_POST['Gmail']);
    $password = trim($_POST['password']);

    // Query to find doctor by Gmail
    $query = "SELECT * FROM doctors WHERE Gmail = ?";
    if ($stmt = $conn->prepare($query)) {
        $stmt->bind_param("s", $Gmail);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $storedPassword = $row['password'];

            // Verify password
            if (password_verify($password, $storedPassword)) {
                session_start();
                $_SESSION['doctor_name'] = $row['name'];
                header("Location: /DIC/doctor/index.php"); // Redirect to doctor dashboard
                exit();
            } else {
                $message = "<p class='error'>Incorrect password.</p>";
            }
        } else {
            $message = "<p class='error'>Doctor not found.</p>";
        }

        $stmt->close();
    } else {
        $message = "<p class='error'>Error preparing the statement.</p>";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Login - Doc in a Click</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f9f9f9;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }
        .login-container {
            background: #ffffff;
            padding: 20px 30px;
            border-radius: 12px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 350px;
            text-align: center;
        }
        h2 {
            margin-bottom: 20px;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        input[type="email"], input[type="password"] {
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ddd;
            border-radius: 8px;
        }
        button {
            background-color: #4CAF50;
            color: white;
            padding: 12px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #45a049;
        }
        .message {
            margin-top: 15px;
        }
        .error {
            color: red;
        }
        .success {
            color: green;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Doctor Login</h2>
        <?php echo $message; ?>
        <form action="" method="POST">
            <input type="email" name="Gmail" placeholder="Enter Gmail" required>
            <input type="password" name="password" placeholder="Enter Password" required>
            <button type="submit">Login</button>
        </form>
    </div>
</body>
</html>
